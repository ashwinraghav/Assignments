gcc -fopenmp -o test_user_theory -I ../../include -L ../../lib -lz3 test_user_theory.c
