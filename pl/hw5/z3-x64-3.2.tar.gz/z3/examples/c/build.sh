gcc -fopenmp -o test_capi -I ../../include -L ../../lib -lz3 test_capi.c
