gcc -fopenmp -o maxsat -I ../../include -L ../../lib -lz3 maxsat.c
