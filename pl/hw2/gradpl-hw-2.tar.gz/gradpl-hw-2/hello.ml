(* Hello, World *)

let main () =
  Printf.printf "Hello, world.\n" ;
  exit 0
;;
main () ;;
